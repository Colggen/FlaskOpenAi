# -*- encoding: utf-8 -*-

# import Flask 
from flask import Flask
from webpart.apps.config import Config
from flask_sqlalchemy import SQLAlchemy


# Inject Flask magic
db = SQLAlchemy()

app = Flask(__name__)

# load Configuration
app.config.from_object(Config)
app.config['SQLALCHEMY_DATABASE_URI'] = r'sqlite:////Users/a1231/Downloads/mainprojflask/webpart/allusers'
# Import routing to render the pages
with app.app_context():
    db.init_app(app)

from webpart.apps import views
