# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

from webpart.apps import *



app.logger.info('DEBUG       = ' + str( app.config['DEBUG']))
app.logger.info('ASSETS_ROOT = ' + app.config['ASSETS_ROOT'])
app.logger.info('UPLOAD_FILE = ' + app.config['UPLOAD_FOLDER'])

# init function run
if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        app.run(port=8000,debug=True)

