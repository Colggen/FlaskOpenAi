# Main FastAPI app
from io import BytesIO

from fastapi import Depends, FastAPI, HTTPException
from fastapi import FastAPI, File, UploadFile
import os.path
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
import uvicorn
import zipfile
from io import BytesIO
from fastapi.responses import HTMLResponse
from flask import Response

from sqlalchemy.orm import Session
from starlette.responses import FileResponse
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename

import crud, models, schemas
from database import SessionLocal, engine
from fastapi.middleware.wsgi import WSGIMiddleware

from webpart.apps.views import app

import os
import zipfile
from fastapi.responses import StreamingResponse


# Create the database tables
models.Base.metadata.create_all(bind=engine)

# craete fastapi (app) instance
fapp = FastAPI()


# need to have an independent database session/connection
# this function lets us to use the same connection throughout request lifecycle
# to accomplish the task above we will use this function as dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    # even if we catch an error the connection is gonna be closed
    finally:
        db.close()

def zipfiles(file_list):
    io = BytesIO()
    zip_sub_dir = "final_archive"
    zip_filename = "%s.zip" % zip_sub_dir
    with zipfile.ZipFile(io, mode='w', compression=zipfile.ZIP_DEFLATED) as zip:
        for fpath in file_list:
            zip.write(fpath)
        #close zip
        zip.close()
    return StreamingResponse(
        iter([io.getvalue()]),
        media_type="application/x-zip-compressed",
        headers = { "Content-Disposition":f"attachment;filename=%s" % zip_filename}
    )

# Depends here is needed to share database connections
@fapp.post("/api/users/create", response_model=schemas.User)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    new_user = crud.get_user_by_login(db, user_login=user.login)

    if new_user:
        raise HTTPException(status_code=400, detail="Login is already taken by another user. Use another, dattebayo.")
    return crud.create_user(db=db, user=user)




# getting all users and their cars actually because of back populates
@fapp.get("/all_users/", response_model=list[schemas.User])
def get_users(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    users = crud.get_all_users(db)
    return users


# getting user(s) by their first name
@fapp.get("/all_users/fname/{user_fname}", response_model=list[schemas.User])
def get_users_by_name(user_fname, skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    users = crud.get_user_by_fname(db=db, user_fname=user_fname)
    return users

@fapp.get("/all_users/sname/{user_sname}", response_model=list[schemas.User])
def get_users_by_second_name(user_sname, skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    users = crud.get_user_by_sname(db=db, user_sname=user_sname)
    return users

@fapp.get("/users/{user_id}", response_model=list[schemas.User])
def get_users_by_user_id(user_id, skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    users = crud.get_user_by_user_id(db=db, user_id=user_id)
    return users

# getting a user with a specific login which is unique
@fapp.get("/api/users/{login}", response_model=schemas.User)
def get_certain_user(login, db: Session = Depends(get_db)):
    return crud.get_user_by_login(db, login)

@fapp.get("/files/", response_model=list[schemas.File])
def get_all_files(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    filenames = crud.get_all_files(db)
    list = []
    for file in filenames:
        list.append('/Users/a1231/Downloads/mainprojflask/webpart/apps/static/assets/files/'+file.file_path)
    return zipfiles(list)


@fapp.post("/uploadfile/")
async def create_upload_file(file: UploadFile,user_id: int,db: Session = Depends(get_db)):
    name_of_file = file.filename
    new_file = models.File(file_path=name_of_file,user_id=user_id)
    db.add(new_file)
    db.commit()
    db.refresh(new_file)
    return new_file

# @fapp.get("/file/{file_id}/", response_model=schemas.File)
# def get_file(file_id: int, db: Session = Depends(get_db)):
#     return crud.get_file_by_id(db, file_id)

@fapp.get("/file/{file_id}/")
def get_file(file_id: int, db: Session = Depends(get_db)):
    query = crud.get_file_by_id(db, file_id)
    ans = str(query)
    file_path = "/Users/a1231/Downloads/mainprojflask/webpart/apps/static/assets/files/"+ans[2:len(ans)-3]
    print(file_path)
    return FileResponse(path=file_path, filename=file_path)


@fapp.get("/user_files/{user_id}/")
def get_file(user_id: int, db: Session = Depends(get_db)):
    query = crud.get_all_files_by_user_id(db,user_id)
    return query

fapp.mount('/', WSGIMiddleware(app))
