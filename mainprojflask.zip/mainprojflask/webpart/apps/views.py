# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""
import os.path
import re

import openai
# Flask modules
from flaskapp import *
from flask import render_template
from flask import request, session, redirect, url_for
from werkzeug.utils import secure_filename
from flask import send_from_directory
# App modules
from webpart.apps import *
from webpart.apps import app
from webpart.database import crud
from webpart.database.models import db, User,File

openai.api_key = "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"

messages = []


# App main route + generic routing
@app.route('/')
def home(context=None):
    return render_template("home/index.html",context=context)

@app.route("/register" ,methods=["GET", "POST"])
def register(context=None):
    if request.method == "POST":
        login = request.form['login']
        fname = request.form['fname']
        sname = request.form['sname']
        pass1 = request.form['password']
        pass2 = request.form['password_conf']

        print(login, fname, sname, pass1, pass2)

        data = db.session.query(User).filter_by(login=request.form['login']).first()

        if data:
            return render_template("home/register.html",context="The user with this login already exists!")
            # return redirect(url_for("register", error="Already registered!"))
        elif pass1 != pass2:
            return render_template("home/register.html",context="Passwords do not match!")
            # return redirect(url_for("register", error="Passowords do not match!"))
        else:
            crud.add_user(User(login=login,
                               user_fname=fname,
                               user_sname=sname,
                               password=pass1))

        return redirect(url_for("login", context="Succesfully registered!"))

    return render_template("home/register.html",context=context)


@app.route("/login", methods=["GET", "POST"])
def login(context=None):
    if request.method == "POST":

        user = db.session.query(User).filter_by(login=request.form['login'], password=request.form['password']).first()
        print(user)
        if user:
            session['authenticated'] = True
            session['uid'] = user.user_id
            session['username'] = user.user_fname
            return redirect(url_for("ask", user_id=user.user_id))
        else:
            return render_template("home/login.html", context="The login or password were wrong")

    return render_template("home/login.html", context=context)


@app.route("/upload", methods=["GET", "POST"])
def upload_file(context='File Uploading'):
    if request.method=="POST":
        file = request.files["file"]
        file.save(os.path.join(os.path.abspath(os.path.dirname(__file__)),app.config['UPLOAD_FOLDER'],secure_filename(file.filename)))

        path_for_file = 'file://'+os.path.join(os.path.abspath(os.path.dirname(__file__)),app.config['UPLOAD_FOLDER'],secure_filename(file.filename))

        print(file.filename)
        if 'file' not in request.files:
            return redirect(request.url)
        crud.add_file(File(file_path=file.filename,user_id=session['uid']))
        return render_template("home/file_upload.html",context="Succesfully uploaded")

    return render_template("home/file_upload.html", context=context)


# @app.route('/upload/<path:filename>')
# def download_file(filename):
#     dbfile = db.session.query(File).filter(filename == File.file_path).first()
#     return send_from_directory(app.config['UPLOAD_FOLDER'],
#                                dbfile.file_path)
@app.route('/uploads/<file_id>')
def download_file(file_id):
    dbfile = db.session.query(File).filter(File.user_id == file_id).first()
    if dbfile:
        return send_from_directory(app.config['UPLOAD_FOLDER'], dbfile.file_path
                                   )
    return render_template("home/file_upload.html", context="You did not upload any file yet")

@app.route('/users')
def find_users():
    all_users = crud.get_all_users()
    all_files = crud.get_all_files()
    # ala = request.form['user_files']
    # session['id_file'] = 1
    # print(ala)

    # a = []
    # for file in all_files:
    #     a.append(file.file_path)
    #
    # print(a)


        # if query:
    # for file in all_files:
    #     session['id_file'] = file.file_id
    # if files:
        # return send_from_directory(app.config['UPLOAD_FOLDER'], dbfile.file_path, as_attachment=True)
    return render_template("home/find_users.html", users=all_users,files=all_files)
    # else:
    #     query = db.session.query(User).filter(User.user_id == session['uid']).first()
    #     return render_template("home/find_users.html", context=query)


@app.route("/user/<int:user_id>")
def user_page(user_id):
    query = db.session.query(User.login, User.user_fname, User.user_sname).filter(User.user_id == user_id).first()
    print(query)
    if query:
        return render_template("home/user.html", context=query)
    else:
        query = db.session.query(User).filter(User.user_id == user_id).first()
        return render_template("home/user.html",context=query)

@app.route("/map")
def map(context=None):
    return render_template("home/map.html",context = context)

@app.route("/logout")
def logout():
    a=''
    session.pop('authenticated', None)
    session.pop('uid', None)
    session.pop('username', None)
    return redirect(url_for('home'))



@app.route('/ask', methods=['GET', 'POST'])
def ask():
    if request.method =='POST':
        user_message = request.form['user_message']
        messages.append({"role": "user", "content": user_message})

        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=messages
        )

        reply = response["choices"][0]["message"]["content"]
        messages.append({"role": "assistant", "content": reply})
        return render_template('home/ask.html', messages=messages)

    return render_template('home/ask.html', messages=messages)
