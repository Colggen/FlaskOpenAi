from flask_sqlalchemy import SQLAlchemy
from webpart.apps import app
from webpart.apps import db
from database import Base

class User(Base):
    __tablename__ = "users"
    __table_args__ = {'extend_existing': True}
    user_id = db.Column(db.Integer, primary_key=True)  # integer primary key will be autoincremented by default
    login = db.Column(db.String(255), unique=True, nullable=False)
    user_fname = db.Column(db.String(255))
    user_sname = db.Column(db.String(255))
    password = db.Column(db.String(255), nullable=False)

    # user_cars = db.relationship("Car", back_populates="owner", cascade="all, delete-orphan")

    user_files = db.relationship("File", back_populates="file", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"User(user_id {self.user_id!r}, login={self.login!r},name={self.user_fname!r}, surname={self.user_fname!r})"


class File(Base):
    __tablename__ = "files"
    __table_args__ = {'extend_existing': True}
    file_id = db.Column(db.Integer, primary_key=True)  # integer primary key will be autoincremented by default
    file_path = db.Column(db.String(255), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey("users.user_id"), nullable=False)

    file = db.relationship("User", back_populates="user_files")

    def __repr__(self) -> str:
        return f"File(file_id={self.file_id!r}, file_path={self.file_path!r},user_id={self.user_id!r})"
